package com.flp.pms.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;

public interface IProductDao 
{
	public List<Category> getAllCategory();
	public List<Sub_Category> getAllSubCategory();
public List<Supplier> getAllSuppliers();
public List<Discount> getAllDiscounts();
public List<Product> viewAllProducts();
	
	public void addProduct(Product product);
	public boolean removeProduct(int productid) ;
	public Map<Integer, Product> getAllProducts();
	public ArrayList<Product> searchByProductName();
	public ArrayList<Product> searchBySupplierName();
	public ArrayList<Product> searchByCategoryName() ;
	public ArrayList<Product> searchBySubCategory();
	public ArrayList<Product> searchByRatings();

	public void updateProductName(int productId,Product p, String pName);
	public void updateRetailPrice(int productId,Product p, double price);
	public void updateExpiryDate(int productId,Product p, Date date);
	public void updateRating(int productId,Product p, float ratings);
	public void updateCategory(int productId,Product p, Category category);
	
}
